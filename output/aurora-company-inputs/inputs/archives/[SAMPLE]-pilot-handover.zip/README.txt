[SAMPLE] Fictional Aurora Labs company record. Not research findings.
Contained files are duplicates of separately supplied source records.
